"""
bringup.launch.py
=================
Master launch file for the multifloor navigation stack.

Starts in order:
  1. Gazebo Classic with the multifloor world
  2. robot_state_publisher  (URDF → /tf)
  3. spawn_entity           (robot into Gazebo)
  4. Nav2 lifecycle nodes   (map_server, amcl, planner, controller, bt_navigator,
                              behavior_server, smoother, velocity_smoother,
                              waypoint_follower, collision_monitor)
  5. nav2_lifecycle_manager (activates the entire Nav2 stack automatically)
  6. map_manager_node       (SwitchFloor srv → calls LoadMap)
  7. elevator_manager_node  (FSM)
  8. mission_coordinator_node (NavigateToPose action client)

Design: ONE Nav2 stack — the lifecycle_manager manages all Nav2 nodes.
        map_manager calls map_server/load_map when a floor switch is requested.
"""

import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    IncludeLaunchDescription,
    LogInfo,
    RegisterEventHandler,
    TimerAction,
)
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
    PythonExpression,
)
from launch_ros.actions import Node, LifecycleNode
from launch_ros.substitutions import FindPackageShare


def generate_launch_description() -> LaunchDescription:

    # ── Package share directories ──────────────────────────────────────────
    gazebo_pkg   = get_package_share_directory("multifloor_gazebo")
    nav2_pkg     = get_package_share_directory("multifloor_nav2")
    map_mgr_pkg  = get_package_share_directory("map_manager")
    elev_pkg     = get_package_share_directory("elevator_manager")
    coord_pkg    = get_package_share_directory("mission_coordinator")

    bringup_pkg    = get_package_share_directory("multifloor_bringup")

    # ── File paths ─────────────────────────────────────────────────────────
    world_file       = str(Path(gazebo_pkg) / "worlds"  / "multifloor.world")
    urdf_xacro_file  = str(Path(gazebo_pkg) / "urdf"    / "robot.urdf.xacro")
    maps_dir         = str(Path(gazebo_pkg) / "maps")
    nav2_params_file = str(Path(nav2_pkg)   / "config"  / "nav2_params.yaml")
    map_mgr_params   = str(Path(map_mgr_pkg) / "config" / "map_manager_params.yaml")
    elev_params      = str(Path(elev_pkg)    / "config" / "elevator_manager_params.yaml")
    coord_params     = str(Path(coord_pkg)   / "config" / "mission_coordinator_params.yaml")
    rviz_config      = str(Path(bringup_pkg) / "config" / "multifloor_nav.rviz")

    floor1_yaml = str(Path(maps_dir) / "floor_1.yaml")
    floor2_yaml = str(Path(maps_dir) / "floor_2.yaml")

    # ── Launch arguments ───────────────────────────────────────────────────
    use_sim_time_arg = DeclareLaunchArgument(
        "use_sim_time", default_value="true",
        description="Use Gazebo simulation clock")

    headless_arg = DeclareLaunchArgument(
        "headless", default_value="false",
        description="Run Gazebo without GUI (gzserver only)")

    rviz_arg = DeclareLaunchArgument(
        "rviz", default_value="true",
        description="Launch RViz2 for visualisation")

    use_sim_time = LaunchConfiguration("use_sim_time")
    headless     = LaunchConfiguration("headless")
    use_rviz     = LaunchConfiguration("rviz")

    # ── 1. Gazebo ──────────────────────────────────────────────────────────
    # gzserver (always)
    gzserver = ExecuteProcess(
        cmd=["gzserver", "--verbose", "-s", "libgazebo_ros_init.so",
             "-s", "libgazebo_ros_factory.so", world_file],
        output="screen",
    )

    # gzclient — shown unless headless:=true
    gzclient = ExecuteProcess(
        cmd=["gzclient"],
        output="screen",
        condition=UnlessCondition(headless),
    )

    # ── RViz2 ──────────────────────────────────────────────────────────────
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", rviz_config],
        parameters=[{"use_sim_time": use_sim_time}],
        condition=IfCondition(use_rviz),
    )

    # ── 2. robot_state_publisher ───────────────────────────────────────────
    robot_description = Command([
        FindExecutable(name="xacro"), " ", urdf_xacro_file
    ])

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{
            "use_sim_time": use_sim_time,
            "robot_description": robot_description,
        }],
    )

    # ── 3. Spawn robot ─────────────────────────────────────────────────────
    # Robot starts at (2, 5, 0) — centre of Floor-1 room
    spawn_robot = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        name="spawn_robot",
        output="screen",
        arguments=[
            "-entity", "multifloor_robot",
            "-topic",  "robot_description",
            "-x", "2.0",
            "-y", "5.0",
            "-z", "0.05",
            "-Y", "0.0",
        ],
    )

    # ── 4. Nav2 lifecycle nodes ────────────────────────────────────────────
    #
    # map_server  — lifecycle node; starts with floor_1 map.
    #               map_manager will call its load_map service on floor switch.
    map_server = LifecycleNode(
        package="nav2_map_server",
        executable="map_server",
        name="map_server",
        namespace="",
        output="screen",
        parameters=[
            nav2_params_file,
            {
                "use_sim_time":    use_sim_time,
                "yaml_filename":   floor1_yaml,
            },
        ],
    )

    # amcl — localisation
    amcl = LifecycleNode(
        package="nav2_amcl",
        executable="amcl",
        name="amcl",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # planner_server
    planner_server = LifecycleNode(
        package="nav2_planner",
        executable="planner_server",
        name="planner_server",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # controller_server
    controller_server = LifecycleNode(
        package="nav2_controller",
        executable="controller_server",
        name="controller_server",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
        remappings=[("cmd_vel", "cmd_vel_nav")],
    )

    # smoother_server
    smoother_server = LifecycleNode(
        package="nav2_smoother",
        executable="smoother_server",
        name="smoother_server",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # behavior_server
    behavior_server = LifecycleNode(
        package="nav2_behaviors",
        executable="behavior_server",
        name="behavior_server",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # bt_navigator
    bt_navigator = LifecycleNode(
        package="nav2_bt_navigator",
        executable="bt_navigator",
        name="bt_navigator",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # waypoint_follower
    waypoint_follower = LifecycleNode(
        package="nav2_waypoint_follower",
        executable="waypoint_follower",
        name="waypoint_follower",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # velocity_smoother
    velocity_smoother = LifecycleNode(
        package="nav2_velocity_smoother",
        executable="velocity_smoother",
        name="velocity_smoother",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
        remappings=[
            ("cmd_vel",     "cmd_vel_nav"),
            ("cmd_vel_smoothed", "cmd_vel"),
        ],
    )

    # collision_monitor
    collision_monitor = LifecycleNode(
        package="nav2_collision_monitor",
        executable="collision_monitor",
        name="collision_monitor",
        namespace="",
        output="screen",
        parameters=[nav2_params_file, {"use_sim_time": use_sim_time}],
    )

    # ── 5. Nav2 lifecycle manager ──────────────────────────────────────────
    # A single lifecycle_manager controls ALL Nav2 nodes.
    nav2_lifecycle_manager = Node(
        package="nav2_lifecycle_manager",
        executable="lifecycle_manager",
        name="lifecycle_manager_navigation",
        output="screen",
        parameters=[{
            "use_sim_time":  use_sim_time,
            "autostart":     True,
            "node_names": [
                "map_server",
                "amcl",
                "controller_server",
                "smoother_server",
                "planner_server",
                "behavior_server",
                "bt_navigator",
                "waypoint_follower",
                "velocity_smoother",
                "collision_monitor",
            ],
        }],
    )

    # ── 6. map_manager — with absolute map-yaml paths ─────────────────────
    map_manager_node = Node(
        package="map_manager",
        executable="map_manager_node",
        name="map_manager_node",
        output="screen",
        parameters=[
            map_mgr_params,
            {
                "use_sim_time":      use_sim_time,
                "floor_1.map_yaml":  floor1_yaml,
                "floor_2.map_yaml":  floor2_yaml,
            },
        ],
    )

    # ── 7. elevator_manager ────────────────────────────────────────────────
    elevator_manager_node = Node(
        package="elevator_manager",
        executable="elevator_manager_node",
        name="elevator_manager_node",
        output="screen",
        parameters=[elev_params, {"use_sim_time": use_sim_time}],
    )

    # ── 8. mission_coordinator ─────────────────────────────────────────────
    mission_coordinator_node = Node(
        package="mission_coordinator",
        executable="mission_coordinator_node",
        name="mission_coordinator_node",
        output="screen",
        parameters=[
            coord_params,
            {
                "use_sim_time":    use_sim_time,
                "elevator_pos_x":  13.0,   # corridor centre x (world coords)
                "elevator_pos_y":  5.0,    # corridor centre y
            },
        ],
    )

    # ── Assemble ───────────────────────────────────────────────────────────
    return LaunchDescription([
        use_sim_time_arg,
        headless_arg,
        rviz_arg,

        LogInfo(msg="=== [1/5] Starting Gazebo ==="),
        gzserver,
        gzclient,
        rviz_node,

        LogInfo(msg="=== [2/5] Starting robot_state_publisher ==="),
        robot_state_publisher,

        # Slight delay before spawning so Gazebo factory service is ready
        TimerAction(
            period=3.0,
            actions=[
                LogInfo(msg="=== [3/5] Spawning robot ==="),
                spawn_robot,
            ],
        ),

        LogInfo(msg="=== [4/5] Starting Nav2 nodes ==="),
        map_server,
        amcl,
        planner_server,
        controller_server,
        smoother_server,
        behavior_server,
        bt_navigator,
        waypoint_follower,
        velocity_smoother,
        collision_monitor,

        # lifecycle_manager starts after a short delay so all nodes are registered
        TimerAction(
            period=5.0,
            actions=[
                LogInfo(msg="=== [4b] Starting Nav2 lifecycle manager ==="),
                nav2_lifecycle_manager,
            ],
        ),

        LogInfo(msg="=== [5/5] Starting custom multifloor nodes ==="),
        map_manager_node,
        elevator_manager_node,
        mission_coordinator_node,

        LogInfo(msg="=== All nodes launched. System ready. ==="),
    ])
