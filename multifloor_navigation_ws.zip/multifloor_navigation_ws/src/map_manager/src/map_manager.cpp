#include "map_manager/map_manager.hpp"

#include <chrono>
#include <functional>

using namespace std::chrono_literals;

namespace map_manager
{

MapManager::MapManager(const rclcpp::NodeOptions & options)
: Node("map_manager_node", options),
  current_floor_(1)
{
  declare_and_load_parameters();
  setup_communication();

  RCLCPP_INFO(get_logger(), "MapManager initialized. Current floor: %d", current_floor_);
  RCLCPP_INFO(get_logger(),
    "Will call map_server/load_map on every SwitchFloor request.");
}

// ── Parameters ─────────────────────────────────────────────────────────

void MapManager::declare_and_load_parameters()
{
  declare_parameter<int>("initial_floor", 1);
  // Full absolute paths are expected here; set from launch via parameter override.
  declare_parameter<std::string>("floor_1.map_yaml", "floor_1.yaml");
  declare_parameter<std::string>("floor_1.frame_id", "map");
  declare_parameter<std::string>("floor_2.map_yaml", "floor_2.yaml");
  declare_parameter<std::string>("floor_2.frame_id", "map");

  current_floor_ = get_parameter("initial_floor").as_int();

  FloorMapConfig floor1_cfg;
  floor1_cfg.floor_number = 1;
  floor1_cfg.map_yaml     = get_parameter("floor_1.map_yaml").as_string();
  floor1_cfg.frame_id     = get_parameter("floor_1.frame_id").as_string();
  floor_map_configs_[1]   = floor1_cfg;

  FloorMapConfig floor2_cfg;
  floor2_cfg.floor_number = 2;
  floor2_cfg.map_yaml     = get_parameter("floor_2.map_yaml").as_string();
  floor2_cfg.frame_id     = get_parameter("floor_2.frame_id").as_string();
  floor_map_configs_[2]   = floor2_cfg;

  RCLCPP_INFO(get_logger(), "Floor 1 map yaml: %s", floor1_cfg.map_yaml.c_str());
  RCLCPP_INFO(get_logger(), "Floor 2 map yaml: %s", floor2_cfg.map_yaml.c_str());
}

// ── Communication setup ────────────────────────────────────────────────

void MapManager::setup_communication()
{
  floor_info_pub_ = create_publisher<multifloor_interfaces::msg::FloorInfo>(
    "current_floor_info", 10);

  switch_floor_srv_ = create_service<multifloor_interfaces::srv::SwitchFloor>(
    "switch_floor",
    std::bind(&MapManager::handle_switch_floor, this,
      std::placeholders::_1, std::placeholders::_2));

  get_current_floor_srv_ = create_service<multifloor_interfaces::srv::GetCurrentFloor>(
    "get_current_floor",
    std::bind(&MapManager::handle_get_current_floor, this,
      std::placeholders::_1, std::placeholders::_2));

  // Nav2 LoadMap client — targets the map_server lifecycle node
  load_map_client_ = create_client<nav2_msgs::srv::LoadMap>("map_server/load_map");

  // Publish floor info at 1 Hz
  publish_timer_ = create_wall_timer(
    1s, std::bind(&MapManager::publish_floor_info, this));
}

void MapManager::publish_floor_info()
{
  auto msg = multifloor_interfaces::msg::FloorInfo{};
  msg.current_floor = current_floor_;
  floor_info_pub_->publish(msg);
}

// ── Real Nav2 map load ─────────────────────────────────────────────────

bool MapManager::load_floor_map(int floor)
{
  auto it = floor_map_configs_.find(floor);
  if (it == floor_map_configs_.end()) {
    RCLCPP_ERROR(get_logger(), "No map config for floor %d", floor);
    return false;
  }

  const auto & cfg = it->second;
  RCLCPP_INFO(get_logger(),
    "[MapManager] Calling map_server/load_map: '%s' for floor %d",
    cfg.map_yaml.c_str(), floor);

  // Wait for the map_server service to be available (up to 5 s).
  if (!load_map_client_->wait_for_service(5s)) {
    RCLCPP_ERROR(get_logger(),
      "[MapManager] map_server/load_map service not available (is Nav2 running?)");
    return false;
  }

  auto request = std::make_shared<nav2_msgs::srv::LoadMap::Request>();
  request->map_url = cfg.map_yaml;

  auto future = load_map_client_->async_send_request(request);

  // Spin locally until the response is ready (up to 10 s).
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  while (std::chrono::steady_clock::now() < deadline) {
    if (future.wait_for(200ms) == std::future_status::ready) {
      break;
    }
    rclcpp::spin_some(get_node_base_interface());
  }

  if (future.wait_for(0ms) != std::future_status::ready) {
    RCLCPP_ERROR(get_logger(), "[MapManager] load_map service call timed out.");
    return false;
  }

  auto response = future.get();
  // nav2_msgs/srv/LoadMap.srv: result field is uint8, 0 = success
  if (response->result == nav2_msgs::srv::LoadMap::Response::RESULT_SUCCESS) {
    RCLCPP_INFO(get_logger(),
      "[MapManager] Map loaded successfully for floor %d.", floor);
    return true;
  } else {
    RCLCPP_ERROR(get_logger(),
      "[MapManager] LoadMap returned error code %u for floor %d.",
      static_cast<unsigned>(response->result), floor);
    return false;
  }
}

// ── Service handlers ───────────────────────────────────────────────────

void MapManager::handle_switch_floor(
  const std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Request> request,
  std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Response> response)
{
  const int target = request->target_floor;
  RCLCPP_INFO(get_logger(), "SwitchFloor request: floor %d → floor %d",
    current_floor_, target);

  if (floor_map_configs_.find(target) == floor_map_configs_.end()) {
    response->success = false;
    response->message = "Unknown floor: " + std::to_string(target);
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
    return;
  }

  if (load_floor_map(target)) {
    current_floor_ = target;
    response->success = true;
    response->message = "Switched to floor " + std::to_string(target);
    RCLCPP_INFO(get_logger(), "Successfully switched to floor %d", current_floor_);
  } else {
    response->success = false;
    response->message = "Failed to load map for floor " + std::to_string(target);
    RCLCPP_ERROR(get_logger(), "%s", response->message.c_str());
  }
}

void MapManager::handle_get_current_floor(
  const std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Request> /*request*/,
  std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Response> response)
{
  response->current_floor = current_floor_;
}

}  // namespace map_manager
