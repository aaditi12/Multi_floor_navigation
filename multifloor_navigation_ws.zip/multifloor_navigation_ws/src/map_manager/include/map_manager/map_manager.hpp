#pragma once

#include <string>
#include <unordered_map>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "nav2_msgs/srv/load_map.hpp"
#include "multifloor_interfaces/msg/floor_info.hpp"
#include "multifloor_interfaces/srv/switch_floor.hpp"
#include "multifloor_interfaces/srv/get_current_floor.hpp"

namespace map_manager
{

struct FloorMapConfig
{
  std::string map_yaml;    // absolute path to the floor's .yaml map file
  std::string frame_id;
  int floor_number;
};

class MapManager : public rclcpp::Node
{
public:
  explicit MapManager(const rclcpp::NodeOptions & options = rclcpp::NodeOptions{});
  ~MapManager() = default;

private:
  // ── ROS2 communication ────────────────────────────────────────────────
  rclcpp::Publisher<multifloor_interfaces::msg::FloorInfo>::SharedPtr floor_info_pub_;
  rclcpp::Service<multifloor_interfaces::srv::SwitchFloor>::SharedPtr switch_floor_srv_;
  rclcpp::Service<multifloor_interfaces::srv::GetCurrentFloor>::SharedPtr get_current_floor_srv_;
  rclcpp::TimerBase::SharedPtr publish_timer_;

  /// Nav2 map_server/load_map service client
  rclcpp::Client<nav2_msgs::srv::LoadMap>::SharedPtr load_map_client_;

  // ── State ──────────────────────────────────────────────────────────────
  int current_floor_;
  std::unordered_map<int, FloorMapConfig> floor_map_configs_;

  // ── Methods ────────────────────────────────────────────────────────────
  void declare_and_load_parameters();
  void setup_communication();
  void publish_floor_info();

  /// Calls Nav2's map_server/load_map service.  Returns true on success.
  bool load_floor_map(int floor);

  void handle_switch_floor(
    const std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Request> request,
    std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Response> response);

  void handle_get_current_floor(
    const std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Request> request,
    std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Response> response);
};

}  // namespace map_manager
