#!/usr/bin/env python3
"""
generate_maps.py
================
Generates two Nav2-compatible occupancy-grid maps (PGM + YAML) that match
the Gazebo world geometry in multifloor.world.

World layout (all values in metres):
  Floor-1 room : x=[0,12],  y=[0,10]
  Corridor     : x=[12,16], y=[0,10]   (doorways centred at y=5, width 2 m)
  Floor-2 room : x=[16,28], y=[0,10]

Map convention
  resolution : 0.05 m/cell   →  1 m = 20 cells
  origin     : lower-left corner of the floor coverage area (z=0, yaw=0)
  occupied   : pixel value 0   (black)
  free       : pixel value 254 (white)
  unknown    : pixel value 205 (grey) — unused here

The Floor-1 map covers [0..12]×[0..10] with the corridor included up to x=16
so the robot can drive into the corridor and reach the elevator docking pose.
The Floor-2 map covers [12..28]×[0..10] for the same reason (shared corridor
strip on each map means seamless hand-off after floor switch).

Run from the maps/ directory or anywhere — output paths are passed as args.
Usage:
    python3 generate_maps.py <output_dir>
"""

import sys
import os
import math
import struct

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_pgm(width: int, height: int, pixels: list[int], path: str):
    """Write a P5 (binary) PGM file."""
    header = f"P5\n{width} {height}\n255\n".encode()
    data = bytes(pixels)
    with open(path, "wb") as f:
        f.write(header + data)


def make_yaml(map_pgm_name: str, resolution: float, origin: tuple,
              path: str):
    """Write a Nav2-compatible map YAML file."""
    ox, oy, oyaw = origin
    content = (
        f"image: {map_pgm_name}\n"
        f"resolution: {resolution}\n"
        f"origin: [{ox}, {oy}, {oyaw}]\n"
        f"negate: 0\n"
        f"occupied_thresh: 0.65\n"
        f"free_thresh: 0.196\n"
    )
    with open(path, "w") as f:
        f.write(content)


# ---------------------------------------------------------------------------
# Map geometry constants (metres)
# ---------------------------------------------------------------------------

RESOLUTION   = 0.05      # m per cell
WALL_T       = 0.2       # wall thickness (m)
ROOM_H       = 10.0      # room / corridor height (y)
F1_X0, F1_X1 = 0.0, 16.0   # Floor-1 map covers room + corridor
F2_X0, F2_X1 = 12.0, 28.0  # Floor-2 map covers corridor + room
DOOR_Y_LO    = 4.0       # doorway lower edge (y)
DOOR_Y_HI    = 6.0       # doorway upper edge (y)
F1_ROOM_END  = 12.0      # x where Floor-1 room ends / corridor begins
F2_ROOM_START= 16.0      # x where Floor-2 room begins / corridor ends

OBS_RADIUS   = 0.35      # half-size of obstacle footprint (m)
# obstacles [cx, cy] in world coords
F1_OBSTACLES = [(4.0, 3.0), (8.0, 7.0)]
F2_OBSTACLES = [(20.0, 3.0), (25.0, 7.0)]


def world_to_cell(wx: float, wy: float, ox: float, oy: float, res: float):
    """Convert world (x,y) → (col, row).  Row 0 = bottom of image."""
    col = int((wx - ox) / res)
    row = int((wy - oy) / res)
    return col, row


def build_map(x0: float, x1: float,
              obstacles_world: list,
              wall_left: bool, wall_right: bool) -> tuple[int, int, list[int]]:
    """
    Build an occupancy grid for a map region [x0..x1] × [0..ROOM_H].

    Returns (width, height, pixels) where pixels is stored top-row-first
    (standard PGM) but row index 0 in our grid = bottom (y=0) world coords,
    so we flip when writing.

    Walls drawn:
      - South (y=0) and North (y=ROOM_H) across full width
      - West  (x=x0) if wall_left=True
      - East  (x=x1) if wall_right=True
      - Doorway gap [DOOR_Y_LO .. DOOR_Y_HI] on F1-east / F2-west / corridor walls
        The corridor itself has no inner east/west walls — just the room walls
        that border it.
    """
    res  = RESOLUTION
    cols = int(round((x1 - x0) / res))
    rows = int(round(ROOM_H / res))

    # Start with all free (254)
    grid = [[254] * cols for _ in range(rows)]

    def fill_rect(wx_lo, wx_hi, wy_lo, wy_hi, val=0):
        c0 = max(0, int((wx_lo - x0) / res))
        c1 = min(cols, int(math.ceil((wx_hi - x0) / res)))
        r0 = max(0, int(wy_lo / res))
        r1 = min(rows, int(math.ceil(wy_hi / res)))
        for r in range(r0, r1):
            for c in range(c0, c1):
                grid[r][c] = val

    # ── Outer walls ───────────────────────────────────────────────────────
    # South wall (y = 0)
    fill_rect(x0, x1, 0.0, WALL_T)
    # North wall (y = ROOM_H)
    fill_rect(x0, x1, ROOM_H - WALL_T, ROOM_H)

    # West wall (x = x0) — full height, no doorway (only exterior west)
    if wall_left:
        fill_rect(x0, x0 + WALL_T, 0.0, ROOM_H)

    # East wall (x = x1) — full height, no doorway (only exterior east)
    if wall_right:
        fill_rect(x1 - WALL_T, x1, 0.0, ROOM_H)

    # ── Room divider walls with doorways ──────────────────────────────────
    # For Floor-1 map: east wall of F1 room at x=F1_ROOM_END, with doorway
    if x0 < F1_ROOM_END < x1:
        wx = F1_ROOM_END
        fill_rect(wx - WALL_T / 2, wx + WALL_T / 2, 0.0,       DOOR_Y_LO)
        fill_rect(wx - WALL_T / 2, wx + WALL_T / 2, DOOR_Y_HI, ROOM_H)

    # For Floor-2 map: west wall of F2 room at x=F2_ROOM_START, with doorway
    if x0 < F2_ROOM_START < x1:
        wx = F2_ROOM_START
        fill_rect(wx - WALL_T / 2, wx + WALL_T / 2, 0.0,       DOOR_Y_LO)
        fill_rect(wx - WALL_T / 2, wx + WALL_T / 2, DOOR_Y_HI, ROOM_H)

    # ── Obstacles ────────────────────────────────────────────────────────
    for (cx, cy) in obstacles_world:
        if x0 <= cx <= x1:
            fill_rect(cx - OBS_RADIUS, cx + OBS_RADIUS,
                      cy - OBS_RADIUS, cy + OBS_RADIUS)

    # ── Inflate walls slightly (1 cell) for safety — skip, Nav2 does this
    # via the inflation layer in costmap.

    # Flatten and flip vertically (PGM row 0 = top = high y in world)
    pixels = []
    for r in range(rows - 1, -1, -1):
        pixels.extend(grid[r])

    return cols, rows, pixels


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(out_dir, exist_ok=True)

    # ── Floor-1 map ───────────────────────────────────────────────────────
    w, h, px = build_map(
        x0=F1_X0, x1=F1_X1,
        obstacles_world=F1_OBSTACLES,
        wall_left=True,   # west exterior wall
        wall_right=False  # corridor continues east — no closing wall
    )
    pgm1 = os.path.join(out_dir, "floor_1.pgm")
    yml1 = os.path.join(out_dir, "floor_1.yaml")
    make_pgm(w, h, px, pgm1)
    make_yaml("floor_1.pgm", RESOLUTION, (F1_X0, 0.0, 0.0), yml1)
    print(f"Floor-1 map: {w}×{h} cells → {pgm1}")

    # ── Floor-2 map ───────────────────────────────────────────────────────
    w, h, px = build_map(
        x0=F2_X0, x1=F2_X1,
        obstacles_world=F2_OBSTACLES,
        wall_left=False,  # corridor continues west — no closing wall
        wall_right=True   # east exterior wall
    )
    pgm2 = os.path.join(out_dir, "floor_2.pgm")
    yml2 = os.path.join(out_dir, "floor_2.yaml")
    make_pgm(w, h, px, pgm2)
    make_yaml("floor_2.pgm", RESOLUTION, (F2_X0, 0.0, 0.0), yml2)
    print(f"Floor-2 map: {w}×{h} cells → {pgm2}")


if __name__ == "__main__":
    main()
