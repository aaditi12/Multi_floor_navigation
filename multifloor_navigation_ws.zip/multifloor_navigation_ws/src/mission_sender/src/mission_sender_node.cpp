/**
 * mission_sender_node.cpp
 * =======================
 * Sends a single mission goal to /mission_goal_floor AFTER confirming that
 * mission_coordinator_node is actually subscribed.  This solves the lost-
 * message problem that occurs when `ros2 topic pub --once` fires before the
 * subscriber has connected.
 *
 * Usage (after building and sourcing):
 *
 *   # Cross-floor:  Floor 1 → Floor 2, goal (20, 5)
 *   ros2 run mission_sender mission_sender_node \
 *       --ros-args -p floor:=2 -p x:=20.0 -p y:=5.0
 *
 *   # Same-floor:  Floor 1, goal (8, 7)
 *   ros2 run mission_sender mission_sender_node \
 *       --ros-args -p floor:=1 -p x:=8.0 -p y:=7.0
 *
 * The node exits automatically once the goal is delivered.
 */

#include <chrono>
#include <string>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

using namespace std::chrono_literals;

class MissionSender : public rclcpp::Node
{
public:
  MissionSender()
  : Node("mission_sender_node"), sent_(false)
  {
    // ── Parameters ──────────────────────────────────────────────────────
    declare_parameter<int>("floor", 2);
    declare_parameter<double>("x", 20.0);
    declare_parameter<double>("y", 5.0);

    int    floor = get_parameter("floor").as_int();
    double x     = get_parameter("x").as_double();
    double y     = get_parameter("y").as_double();

    goal_msg_.data = "floor:" + std::to_string(floor) +
                     ",x:"    + std::to_string(x) +
                     ",y:"    + std::to_string(y);

    RCLCPP_INFO(get_logger(),
      "MissionSender ready. Goal = '%s'", goal_msg_.data.c_str());
    RCLCPP_INFO(get_logger(),
      "Waiting for mission_coordinator_node to subscribe to /mission_goal_floor ...");

    // ── Publisher ────────────────────────────────────────────────────────
    // Use TRANSIENT_LOCAL so the message is kept in the publisher's queue
    // and delivered to any subscriber that connects late.
    rclcpp::QoS qos(1);
    qos.transient_local();
    pub_ = create_publisher<std_msgs::msg::String>("mission_goal_floor", qos);

    // ── Timer — poll until a subscriber appears, then send once ─────────
    timer_ = create_wall_timer(
      500ms, std::bind(&MissionSender::try_send, this));
  }

private:
  void try_send()
  {
    if (sent_) {
      return;
    }

    // Wait until mission_coordinator_node has connected
    if (pub_->get_subscription_count() == 0) {
      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 3000,
        "No subscribers yet on /mission_goal_floor — waiting ...");
      return;
    }

    // Subscriber is live — publish once
    pub_->publish(goal_msg_);
    sent_ = true;
    timer_->cancel();

    RCLCPP_INFO(get_logger(),
      "✓ Goal published: '%s'", goal_msg_.data.c_str());
    RCLCPP_INFO(get_logger(),
      "Mission sender done. You can Ctrl-C this node now, "
      "or it will shut down automatically.");

    // Schedule clean shutdown after a short delay
    shutdown_timer_ = create_wall_timer(
      2s, []() { rclcpp::shutdown(); });
  }

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::TimerBase::SharedPtr shutdown_timer_;
  std_msgs::msg::String goal_msg_;
  bool sent_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MissionSender>());
  rclcpp::shutdown();
  return 0;
}
