#pragma once

#include <string>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "geometry_msgs/msg/pose.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/string.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"

#include "multifloor_interfaces/msg/floor_info.hpp"
#include "multifloor_interfaces/msg/elevator_state.hpp"
#include "multifloor_interfaces/srv/switch_floor.hpp"
#include "multifloor_interfaces/srv/get_current_floor.hpp"

namespace mission_coordinator
{

struct MissionGoal
{
  int target_floor{1};
  geometry_msgs::msg::Pose target_pose;
};

enum class MissionState : uint8_t
{
  IDLE                   = 0,
  NAVIGATING_TO_GOAL     = 1,
  NAVIGATING_TO_ELEVATOR = 2,
  WAITING_FOR_ELEVATOR   = 3,
  SWITCHING_FLOOR        = 4,
  MISSION_COMPLETE       = 5,
  MISSION_FAILED         = 6
};

std::string to_string(MissionState state);

/**
 * MissionCoordinator
 * ==================
 * Orchestrates multi-floor navigation missions using a *real* Nav2
 * NavigateToPose action client for all navigation steps.
 *
 * Published topics:
 *   /mission_status        (std_msgs/msg/String)
 *   /elevator_request      (std_msgs/msg/Bool)
 *
 * Subscribed topics:
 *   /current_floor_info    (multifloor_interfaces/msg/FloorInfo)
 *   /elevator_state        (multifloor_interfaces/msg/ElevatorState)
 *   /mission_goal_floor    (std_msgs/msg/String)  — "floor:2,x:10,y:5"
 *
 * Service clients:
 *   /switch_floor          (multifloor_interfaces/srv/SwitchFloor)
 *   /get_current_floor     (multifloor_interfaces/srv/GetCurrentFloor)
 *
 * Action clients:
 *   /navigate_to_pose      (nav2_msgs/action/NavigateToPose)
 */
class MissionCoordinator : public rclcpp::Node
{
public:
  using Nav2Goal    = nav2_msgs::action::NavigateToPose;
  using GoalHandle  = rclcpp_action::ClientGoalHandle<Nav2Goal>;

  explicit MissionCoordinator(const rclcpp::NodeOptions & options = rclcpp::NodeOptions{});
  ~MissionCoordinator();

private:
  // ── State ──────────────────────────────────────────────────────────────
  MissionState mission_state_;
  MissionGoal  active_goal_;
  int          current_floor_;
  std::string  elevator_state_str_;
  std::mutex   state_mutex_;

  double elevator_pos_x_;
  double elevator_pos_y_;

  std::thread       mission_thread_;
  std::atomic<bool> stop_requested_{false};

  // ── ROS2 interfaces ────────────────────────────────────────────────────
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr   mission_status_pub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr     elevator_request_pub_;

  rclcpp::Subscription<multifloor_interfaces::msg::FloorInfo>::SharedPtr     floor_info_sub_;
  rclcpp::Subscription<multifloor_interfaces::msg::ElevatorState>::SharedPtr elevator_state_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr                      goal_sub_;

  rclcpp::Client<multifloor_interfaces::srv::SwitchFloor>::SharedPtr     switch_floor_client_;
  rclcpp::Client<multifloor_interfaces::srv::GetCurrentFloor>::SharedPtr get_floor_client_;

  /// Nav2 NavigateToPose action client (single shared instance = one stack)
  rclcpp_action::Client<Nav2Goal>::SharedPtr nav2_client_;

  // ── Setup ──────────────────────────────────────────────────────────────
  void declare_and_load_parameters();
  void setup_communication();

  // ── Callbacks ──────────────────────────────────────────────────────────
  void on_floor_info(const multifloor_interfaces::msg::FloorInfo::SharedPtr msg);
  void on_elevator_state(const multifloor_interfaces::msg::ElevatorState::SharedPtr msg);
  void on_goal_received(const std_msgs::msg::String::SharedPtr msg);

  // ── Mission logic (runs in mission_thread_) ───────────────────────────
  void execute_mission(MissionGoal goal);

  // ── Navigation primitives ─────────────────────────────────────────────
  /// Sends a NavigateToPose goal to Nav2 and blocks until complete or cancelled.
  bool navigate_to_pose(const geometry_msgs::msg::Pose & pose, const std::string & label);
  bool navigate_to_elevator();
  bool request_elevator_and_wait();
  bool switch_floor(int target_floor);

  // ── Helpers ───────────────────────────────────────────────────────────
  void publish_status(const std::string & status);
  void set_mission_state(MissionState state);
  MissionGoal parse_goal_string(const std::string & raw);
};

}  // namespace mission_coordinator
