# ROS2 Multi-Floor Mission Coordinator

A complete ROS2 Humble workspace demonstrating realistic multi-floor navigation
with elevator-based map switching, implemented in C++17.

## Architecture

```
multifloor_navigation_ws/
└── src/
    ├── multifloor_interfaces/   # Custom msgs & srvs
    ├── map_manager/             # Floor map management + floor switching
    ├── elevator_manager/        # Elevator FSM simulation
    ├── mission_coordinator/     # High-level mission logic
    └── multifloor_bringup/      # Launch files
```

### Node graph

```
/mission_goal_floor (String) ──► MissionCoordinatorNode
                                    │  pub: /elevator_request (Bool)
                                    │  pub: /mission_status (String)
                                    │  sub: /current_floor_info (FloorInfo)
                                    │  sub: /elevator_state (ElevatorState)
                                    │  cli: /switch_floor (SwitchFloor)
                                    │  cli: /get_current_floor (GetCurrentFloor)
                                    │
              ┌─────────────────────┤
              │                     │
     ElevatorManagerNode     MapManagerNode
       pub: /elevator_state    pub: /current_floor_info
       sub: /elevator_request  srv: /switch_floor
                               srv: /get_current_floor
```

### Mission logic

```
if target_floor == current_floor:
    navigate_to_goal()
else:
    navigate_to_elevator()
    request_elevator()           # publishes true on /elevator_request
    wait_until_arrived()         # polls /elevator_state == "ARRIVED"
    switch_floor(target_floor)   # calls /switch_floor service
    navigate_to_goal()
```

### Elevator FSM

```
IDLE ──[request]──► REQUESTED ──[1 s]──► MOVING ──[travel_duration]──► ARRIVED
```

---

## Prerequisites

- ROS2 Humble (Ubuntu 22.04)
- colcon
- C++17 compiler

```bash
source /opt/ros/humble/setup.bash
```

---

## Build

```bash
cd multifloor_navigation_ws
colcon build --symlink-install
source install/setup.bash
```

---

## Run

### Launch all nodes

```bash
ros2 launch multifloor_bringup bringup.launch.py
```

### Send a cross-floor mission (in a new terminal)

```bash
source install/setup.bash

# Go to floor 2, position (10.0, 5.0)
ros2 topic pub --once /mission_goal_floor std_msgs/msg/String \
  "data: 'floor:2,x:10.0,y:5.0'"
```

### Send a same-floor mission

```bash
ros2 topic pub --once /mission_goal_floor std_msgs/msg/String \
  "data: 'floor:1,x:3.0,y:2.0'"
```

### Monitor topics

```bash
# Mission status
ros2 topic echo /mission_status

# Current floor
ros2 topic echo /current_floor_info

# Elevator state
ros2 topic echo /elevator_state
```

### Call services manually

```bash
# Get current floor
ros2 service call /get_current_floor multifloor_interfaces/srv/GetCurrentFloor

# Switch floor directly
ros2 service call /switch_floor multifloor_interfaces/srv/SwitchFloor \
  "{target_floor: 2}"
```

---

## Configuration

Each package has its own YAML under `config/`:

| Package              | Config file                        | Key params                             |
|----------------------|------------------------------------|----------------------------------------|
| map_manager          | map_manager_params.yaml            | initial_floor, floor_1/2.map_file      |
| elevator_manager     | elevator_manager_params.yaml       | travel_duration_sec (default 5.0 s)    |
| mission_coordinator  | mission_coordinator_params.yaml    | elevator_pos_x/y, nav_sim_duration_sec |

---

## Extending to real Nav2

Replace the `navigate_to_goal()` stub in `mission_coordinator.cpp` with a
`nav2_msgs::action::NavigateToPose` action client call, and replace the
`load_floor_map()` stub in `map_manager.cpp` with a
`nav2_msgs::srv::LoadMap` service call to the map_server lifecycle node.
