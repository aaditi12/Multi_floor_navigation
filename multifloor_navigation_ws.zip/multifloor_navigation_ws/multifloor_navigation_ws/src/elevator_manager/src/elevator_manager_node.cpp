#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "elevator_manager/elevator_manager.hpp"

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<elevator_manager::ElevatorManager>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
