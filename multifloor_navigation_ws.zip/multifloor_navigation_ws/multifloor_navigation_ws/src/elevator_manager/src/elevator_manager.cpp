#include "elevator_manager/elevator_manager.hpp"

#include <chrono>
#include <functional>

using namespace std::chrono_literals;

namespace elevator_manager
{

// ─── Helper ────────────────────────────────────────────────────────────────

std::string to_string(ElevatorFsmState state)
{
  switch (state) {
    case ElevatorFsmState::IDLE:      return "IDLE";
    case ElevatorFsmState::REQUESTED: return "REQUESTED";
    case ElevatorFsmState::MOVING:    return "MOVING";
    case ElevatorFsmState::ARRIVED:   return "ARRIVED";
    default:                          return "UNKNOWN";
  }
}

// ─── Constructor ───────────────────────────────────────────────────────────

ElevatorManager::ElevatorManager(const rclcpp::NodeOptions & options)
: Node("elevator_manager_node", options),
  fsm_state_(ElevatorFsmState::IDLE),
  travel_duration_sec_(5.0)
{
  declare_and_load_parameters();
  setup_communication();

  RCLCPP_INFO(get_logger(),
    "ElevatorManager initialized. Travel duration: %.1f s",
    travel_duration_sec_);
}

// ─── Parameters ────────────────────────────────────────────────────────────

void ElevatorManager::declare_and_load_parameters()
{
  declare_parameter<double>("travel_duration_sec", 5.0);
  travel_duration_sec_ = get_parameter("travel_duration_sec").as_double();
}

// ─── Communication setup ───────────────────────────────────────────────────

void ElevatorManager::setup_communication()
{
  state_pub_ = create_publisher<multifloor_interfaces::msg::ElevatorState>(
    "elevator_state", 10);

  request_sub_ = create_subscription<std_msgs::msg::Bool>(
    "elevator_request", 10,
    std::bind(&ElevatorManager::handle_request, this, std::placeholders::_1));

  // Publish state at 2 Hz
  publish_timer_ = create_wall_timer(
    500ms, std::bind(&ElevatorManager::publish_state, this));
}

// ─── State machine ─────────────────────────────────────────────────────────

void ElevatorManager::transition_to(ElevatorFsmState new_state)
{
  RCLCPP_INFO(get_logger(),
    "[ElevatorFSM] %s → %s",
    to_string(fsm_state_).c_str(),
    to_string(new_state).c_str());
  fsm_state_ = new_state;
  publish_state();
}

void ElevatorManager::publish_state()
{
  auto msg = multifloor_interfaces::msg::ElevatorState{};
  msg.state = to_string(fsm_state_);
  state_pub_->publish(msg);
}

// ─── Request callback ──────────────────────────────────────────────────────

void ElevatorManager::handle_request(const std_msgs::msg::Bool::SharedPtr msg)
{
  if (!msg->data) {
    RCLCPP_DEBUG(get_logger(), "Received false on elevator_request — ignored.");
    return;
  }

  if (fsm_state_ != ElevatorFsmState::IDLE && fsm_state_ != ElevatorFsmState::ARRIVED) {
    RCLCPP_WARN(get_logger(),
      "Elevator request received but FSM is in state %s — ignoring.",
      to_string(fsm_state_).c_str());
    return;
  }

  RCLCPP_INFO(get_logger(), "Elevator request received. Starting FSM sequence.");

  // IDLE / ARRIVED → REQUESTED
  transition_to(ElevatorFsmState::REQUESTED);

  // Small delay to simulate door-open / registration, then go MOVING
  // Use a one-shot 1-second timer for the REQUESTED → MOVING transition
  auto requested_delay = create_wall_timer(
    1s,
    [this]() {
      transition_to(ElevatorFsmState::MOVING);

      // Cancel the 1s timer (it already fired once)
      // Start travel timer
      travel_timer_ = create_wall_timer(
        std::chrono::duration<double>(travel_duration_sec_),
        std::bind(&ElevatorManager::on_travel_complete, this));
    });

  // Make the requested_delay fire only once by capturing it
  // We use a shared_ptr trick: the lambda captures the timer and cancels it after first call
  (void)requested_delay;  // ownership transferred to the node's timer list
}

// ─── Travel complete ───────────────────────────────────────────────────────

void ElevatorManager::on_travel_complete()
{
  if (travel_timer_) {
    travel_timer_->cancel();
    travel_timer_.reset();
  }

  if (fsm_state_ == ElevatorFsmState::MOVING) {
    transition_to(ElevatorFsmState::ARRIVED);
    RCLCPP_INFO(get_logger(), "Elevator has ARRIVED at destination floor.");
  }
}

}  // namespace elevator_manager
