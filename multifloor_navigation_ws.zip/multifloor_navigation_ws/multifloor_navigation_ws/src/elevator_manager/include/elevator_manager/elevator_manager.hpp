#pragma once

#include <string>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"
#include "multifloor_interfaces/msg/elevator_state.hpp"

namespace elevator_manager
{

/**
 * @brief Finite state machine states for the elevator.
 */
enum class ElevatorFsmState : uint8_t
{
  IDLE      = 0,
  REQUESTED = 1,
  MOVING    = 2,
  ARRIVED   = 3
};

/**
 * @brief Converts an ElevatorFsmState enum value to its string representation.
 */
std::string to_string(ElevatorFsmState state);

/**
 * @brief ROS2 node that simulates an elevator using a finite state machine.
 *
 * Topics published:
 *   /elevator_state  (multifloor_interfaces/msg/ElevatorState)
 *
 * Topics subscribed:
 *   /elevator_request  (std_msgs/msg/Bool) — true triggers a request
 */
class ElevatorManager : public rclcpp::Node
{
public:
  explicit ElevatorManager(const rclcpp::NodeOptions & options = rclcpp::NodeOptions{});
  ~ElevatorManager() = default;

private:
  // FSM
  ElevatorFsmState fsm_state_;
  double travel_duration_sec_;

  // ROS2
  rclcpp::Publisher<multifloor_interfaces::msg::ElevatorState>::SharedPtr state_pub_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr request_sub_;
  rclcpp::TimerBase::SharedPtr publish_timer_;
  rclcpp::TimerBase::SharedPtr travel_timer_;   // one-shot, activated when MOVING

  // Methods
  void declare_and_load_parameters();
  void setup_communication();
  void publish_state();
  void transition_to(ElevatorFsmState new_state);
  void handle_request(const std_msgs::msg::Bool::SharedPtr msg);
  void on_travel_complete();
};

}  // namespace elevator_manager
