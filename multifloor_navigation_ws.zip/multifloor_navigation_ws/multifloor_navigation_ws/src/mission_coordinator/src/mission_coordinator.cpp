#include "mission_coordinator/mission_coordinator.hpp"

#include <chrono>
#include <functional>
#include <sstream>
#include <stdexcept>

using namespace std::chrono_literals;

namespace mission_coordinator
{

// ─── Helper ────────────────────────────────────────────────────────────────

std::string to_string(MissionState state)
{
  switch (state) {
    case MissionState::IDLE:                   return "IDLE";
    case MissionState::NAVIGATING_TO_GOAL:     return "NAVIGATING_TO_GOAL";
    case MissionState::NAVIGATING_TO_ELEVATOR: return "NAVIGATING_TO_ELEVATOR";
    case MissionState::WAITING_FOR_ELEVATOR:   return "WAITING_FOR_ELEVATOR";
    case MissionState::SWITCHING_FLOOR:        return "SWITCHING_FLOOR";
    case MissionState::MISSION_COMPLETE:       return "MISSION_COMPLETE";
    case MissionState::MISSION_FAILED:         return "MISSION_FAILED";
    default:                                   return "UNKNOWN";
  }
}

// ─── Constructor / Destructor ──────────────────────────────────────────────

MissionCoordinator::MissionCoordinator(const rclcpp::NodeOptions & options)
: Node("mission_coordinator_node", options),
  mission_state_(MissionState::IDLE),
  current_floor_(1),
  elevator_state_str_("IDLE"),
  elevator_pos_x_(5.0),
  elevator_pos_y_(3.0),
  nav_sim_duration_sec_(3.0)
{
  declare_and_load_parameters();
  setup_communication();

  RCLCPP_INFO(get_logger(), "MissionCoordinator initialized and ready.");
  RCLCPP_INFO(get_logger(),
    "Send goals to /mission_goal_floor using format: 'floor:2,x:10.0,y:5.0'");
}

MissionCoordinator::~MissionCoordinator()
{
  stop_requested_ = true;
  if (mission_thread_.joinable()) {
    mission_thread_.join();
  }
}

// ─── Parameters ────────────────────────────────────────────────────────────

void MissionCoordinator::declare_and_load_parameters()
{
  declare_parameter<double>("elevator_pos_x", 5.0);
  declare_parameter<double>("elevator_pos_y", 3.0);
  declare_parameter<double>("nav_sim_duration_sec", 3.0);

  elevator_pos_x_      = get_parameter("elevator_pos_x").as_double();
  elevator_pos_y_      = get_parameter("elevator_pos_y").as_double();
  nav_sim_duration_sec_= get_parameter("nav_sim_duration_sec").as_double();
}

// ─── Communication setup ───────────────────────────────────────────────────

void MissionCoordinator::setup_communication()
{
  // Publishers
  mission_status_pub_ = create_publisher<std_msgs::msg::String>(
    "mission_status", 10);

  elevator_request_pub_ = create_publisher<std_msgs::msg::Bool>(
    "elevator_request", 10);

  // Subscribers
  floor_info_sub_ = create_subscription<multifloor_interfaces::msg::FloorInfo>(
    "current_floor_info", 10,
    std::bind(&MissionCoordinator::on_floor_info, this, std::placeholders::_1));

  elevator_state_sub_ = create_subscription<multifloor_interfaces::msg::ElevatorState>(
    "elevator_state", 10,
    std::bind(&MissionCoordinator::on_elevator_state, this, std::placeholders::_1));

  goal_sub_ = create_subscription<std_msgs::msg::String>(
    "mission_goal_floor", 10,
    std::bind(&MissionCoordinator::on_goal_received, this, std::placeholders::_1));

  // Service clients
  switch_floor_client_ = create_client<multifloor_interfaces::srv::SwitchFloor>(
    "switch_floor");

  get_floor_client_ = create_client<multifloor_interfaces::srv::GetCurrentFloor>(
    "get_current_floor");
}

// ─── Topic Callbacks ───────────────────────────────────────────────────────

void MissionCoordinator::on_floor_info(
  const multifloor_interfaces::msg::FloorInfo::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(state_mutex_);
  current_floor_ = msg->current_floor;
}

void MissionCoordinator::on_elevator_state(
  const multifloor_interfaces::msg::ElevatorState::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(state_mutex_);
  elevator_state_str_ = msg->state;
}

void MissionCoordinator::on_goal_received(
  const std_msgs::msg::String::SharedPtr msg)
{
  if (mission_state_ != MissionState::IDLE &&
      mission_state_ != MissionState::MISSION_COMPLETE &&
      mission_state_ != MissionState::MISSION_FAILED)
  {
    RCLCPP_WARN(get_logger(),
      "Mission already in progress (%s). New goal rejected.",
      to_string(mission_state_).c_str());
    return;
  }

  MissionGoal goal;
  try {
    goal = parse_goal_string(msg->data);
  } catch (const std::exception & e) {
    RCLCPP_ERROR(get_logger(), "Failed to parse goal string '%s': %s",
      msg->data.c_str(), e.what());
    return;
  }

  RCLCPP_INFO(get_logger(),
    "New mission goal: floor=%d, x=%.2f, y=%.2f",
    goal.target_floor, goal.target_pose.position.x, goal.target_pose.position.y);

  // Stop any old thread
  stop_requested_ = true;
  if (mission_thread_.joinable()) {
    mission_thread_.join();
  }
  stop_requested_ = false;

  // Launch mission in background thread so we don't block the ROS2 executor
  mission_thread_ = std::thread(
    &MissionCoordinator::execute_mission, this, goal);
}

// ─── Mission Logic ─────────────────────────────────────────────────────────

void MissionCoordinator::execute_mission(MissionGoal goal)
{
  active_goal_ = goal;

  // Snapshot current floor (thread-safe)
  int start_floor;
  {
    std::lock_guard<std::mutex> lock(state_mutex_);
    start_floor = current_floor_;
  }

  RCLCPP_INFO(get_logger(),
    "======== Mission Start ========\n"
    "  Start floor : %d\n"
    "  Target floor: %d\n"
    "  Goal pose   : (x=%.2f, y=%.2f)",
    start_floor, goal.target_floor,
    goal.target_pose.position.x, goal.target_pose.position.y);

  bool success = false;

  if (goal.target_floor == start_floor) {
    // ── Same floor: navigate directly ──────────────────────────────────
    RCLCPP_INFO(get_logger(), "Target is on the same floor. Navigating directly.");
    set_mission_state(MissionState::NAVIGATING_TO_GOAL);
    success = navigate_to_goal(goal.target_pose, "final goal");
  } else {
    // ── Different floor: elevator sequence ─────────────────────────────

    // Step 1: Navigate to elevator
    set_mission_state(MissionState::NAVIGATING_TO_ELEVATOR);
    if (!navigate_to_elevator()) {
      RCLCPP_ERROR(get_logger(), "Failed to navigate to elevator.");
      set_mission_state(MissionState::MISSION_FAILED);
      publish_status("MISSION_FAILED: could not reach elevator");
      return;
    }
    if (stop_requested_) { return; }

    // Step 2: Request elevator and wait for ARRIVED
    set_mission_state(MissionState::WAITING_FOR_ELEVATOR);
    if (!request_elevator_and_wait()) {
      RCLCPP_ERROR(get_logger(), "Elevator did not arrive in time.");
      set_mission_state(MissionState::MISSION_FAILED);
      publish_status("MISSION_FAILED: elevator timeout");
      return;
    }
    if (stop_requested_) { return; }

    // Step 3: Switch map to destination floor
    set_mission_state(MissionState::SWITCHING_FLOOR);
    if (!switch_floor(goal.target_floor)) {
      RCLCPP_ERROR(get_logger(), "Floor switch failed.");
      set_mission_state(MissionState::MISSION_FAILED);
      publish_status("MISSION_FAILED: floor switch error");
      return;
    }
    if (stop_requested_) { return; }

    // Step 4: Navigate to final goal on new floor
    set_mission_state(MissionState::NAVIGATING_TO_GOAL);
    success = navigate_to_goal(goal.target_pose, "final goal on floor " +
      std::to_string(goal.target_floor));
  }

  if (success) {
    set_mission_state(MissionState::MISSION_COMPLETE);
    publish_status("MISSION_COMPLETE");
    RCLCPP_INFO(get_logger(), "======== Mission Complete ========");
  } else {
    set_mission_state(MissionState::MISSION_FAILED);
    publish_status("MISSION_FAILED: navigation error");
    RCLCPP_ERROR(get_logger(), "======== Mission Failed ========");
  }
}

// ─── Navigation Primitives ─────────────────────────────────────────────────

bool MissionCoordinator::navigate_to_goal(
  const geometry_msgs::msg::Pose & pose,
  const std::string & label)
{
  RCLCPP_INFO(get_logger(),
    "[NAV] Navigating to %s: (x=%.2f, y=%.2f) ...",
    label.c_str(), pose.position.x, pose.position.y);

  // Simulate navigation duration
  const auto steps = static_cast<int>(nav_sim_duration_sec_ * 2);  // check every 0.5s
  for (int i = 0; i < steps; ++i) {
    if (stop_requested_) {
      RCLCPP_WARN(get_logger(), "[NAV] Navigation to '%s' cancelled.", label.c_str());
      return false;
    }
    std::this_thread::sleep_for(500ms);
  }

  RCLCPP_INFO(get_logger(), "[NAV] Reached %s.", label.c_str());
  return true;
}

bool MissionCoordinator::navigate_to_elevator()
{
  geometry_msgs::msg::Pose elevator_pose;
  elevator_pose.position.x = elevator_pos_x_;
  elevator_pose.position.y = elevator_pos_y_;
  elevator_pose.position.z = 0.0;
  elevator_pose.orientation.w = 1.0;

  return navigate_to_goal(elevator_pose, "elevator position");
}

bool MissionCoordinator::request_elevator_and_wait()
{
  RCLCPP_INFO(get_logger(), "[ELEVATOR] Publishing elevator request...");

  auto req_msg = std_msgs::msg::Bool{};
  req_msg.data = true;
  elevator_request_pub_->publish(req_msg);

  // Wait until elevator state becomes ARRIVED (up to 30 s)
  const int max_wait_steps = 60;  // 60 × 500ms = 30 s
  for (int i = 0; i < max_wait_steps; ++i) {
    if (stop_requested_) { return false; }

    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (elevator_state_str_ == "ARRIVED") {
        RCLCPP_INFO(get_logger(), "[ELEVATOR] Elevator ARRIVED. Boarding.");
        return true;
      }
      RCLCPP_DEBUG(get_logger(),
        "[ELEVATOR] Waiting for ARRIVED, current state: %s",
        elevator_state_str_.c_str());
    }
    std::this_thread::sleep_for(500ms);
  }

  return false;  // timeout
}

bool MissionCoordinator::switch_floor(int target_floor)
{
  RCLCPP_INFO(get_logger(), "[MAP] Requesting floor switch to floor %d...", target_floor);

  if (!switch_floor_client_->wait_for_service(5s)) {
    RCLCPP_ERROR(get_logger(), "[MAP] switch_floor service not available.");
    return false;
  }

  auto request = std::make_shared<multifloor_interfaces::srv::SwitchFloor::Request>();
  request->target_floor = target_floor;

  auto future = switch_floor_client_->async_send_request(request);

  // Wait for service response (up to 10 s)
  const auto deadline = std::chrono::steady_clock::now() + 10s;
  while (std::chrono::steady_clock::now() < deadline) {
    if (stop_requested_) { return false; }
    if (future.wait_for(200ms) == std::future_status::ready) {
      break;
    }
  }

  if (future.wait_for(0ms) != std::future_status::ready) {
    RCLCPP_ERROR(get_logger(), "[MAP] switch_floor service call timed out.");
    return false;
  }

  auto response = future.get();
  if (response->success) {
    RCLCPP_INFO(get_logger(), "[MAP] Floor switch succeeded: %s", response->message.c_str());
    std::lock_guard<std::mutex> lock(state_mutex_);
    current_floor_ = target_floor;
    return true;
  } else {
    RCLCPP_ERROR(get_logger(), "[MAP] Floor switch failed: %s", response->message.c_str());
    return false;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────

void MissionCoordinator::set_mission_state(MissionState state)
{
  mission_state_ = state;
  const std::string label = to_string(state);
  RCLCPP_INFO(get_logger(), "[MISSION] State → %s", label.c_str());
  publish_status(label);
}

void MissionCoordinator::publish_status(const std::string & status)
{
  auto msg = std_msgs::msg::String{};
  msg.data = status;
  mission_status_pub_->publish(msg);
}

MissionGoal MissionCoordinator::parse_goal_string(const std::string & raw)
{
  // Expected format: "floor:2,x:10.0,y:5.0"
  MissionGoal goal;
  std::istringstream ss(raw);
  std::string token;

  while (std::getline(ss, token, ',')) {
    const auto colon = token.find(':');
    if (colon == std::string::npos) {
      throw std::invalid_argument("Malformed token: " + token);
    }
    const std::string key   = token.substr(0, colon);
    const std::string value = token.substr(colon + 1);

    if (key == "floor") {
      goal.target_floor = std::stoi(value);
    } else if (key == "x") {
      goal.target_pose.position.x = std::stod(value);
    } else if (key == "y") {
      goal.target_pose.position.y = std::stod(value);
    }
  }

  goal.target_pose.position.z  = 0.0;
  goal.target_pose.orientation.w = 1.0;

  if (goal.target_floor < 1 || goal.target_floor > 2) {
    throw std::out_of_range("target_floor must be 1 or 2, got " +
      std::to_string(goal.target_floor));
  }

  return goal;
}

}  // namespace mission_coordinator
