#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "mission_coordinator/mission_coordinator.hpp"

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<mission_coordinator::MissionCoordinator>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
