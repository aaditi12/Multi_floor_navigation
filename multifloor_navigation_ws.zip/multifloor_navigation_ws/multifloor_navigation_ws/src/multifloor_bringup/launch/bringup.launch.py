"""
bringup.launch.py
-----------------
Launches the full multi-floor navigation stack:
  - map_manager_node
  - elevator_manager_node
  - mission_coordinator_node
"""

from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description() -> LaunchDescription:

    # ── Package share directories ──────────────────────────────────────────
    map_mgr_share       = get_package_share_directory("map_manager")
    elevator_mgr_share  = get_package_share_directory("elevator_manager")
    mission_coord_share = get_package_share_directory("mission_coordinator")
    bringup_share       = get_package_share_directory("multifloor_bringup")

    # ── Parameter file paths ───────────────────────────────────────────────
    map_mgr_params       = str(Path(map_mgr_share)       / "config" / "map_manager_params.yaml")
    elevator_mgr_params  = str(Path(elevator_mgr_share)  / "config" / "elevator_manager_params.yaml")
    mission_coord_params = str(Path(mission_coord_share) / "config" / "mission_coordinator_params.yaml")

    # ── Launch arguments ───────────────────────────────────────────────────
    use_sim_time_arg = DeclareLaunchArgument(
        "use_sim_time",
        default_value="false",
        description="Use simulation (Gazebo) clock if true",
    )
    use_sim_time = LaunchConfiguration("use_sim_time")

    # ── Nodes ──────────────────────────────────────────────────────────────
    map_manager_node = Node(
        package="map_manager",
        executable="map_manager_node",
        name="map_manager_node",
        output="screen",
        parameters=[
            map_mgr_params,
            {"use_sim_time": use_sim_time},
        ],
    )

    elevator_manager_node = Node(
        package="elevator_manager",
        executable="elevator_manager_node",
        name="elevator_manager_node",
        output="screen",
        parameters=[
            elevator_mgr_params,
            {"use_sim_time": use_sim_time},
        ],
    )

    mission_coordinator_node = Node(
        package="mission_coordinator",
        executable="mission_coordinator_node",
        name="mission_coordinator_node",
        output="screen",
        parameters=[
            mission_coord_params,
            {"use_sim_time": use_sim_time},
        ],
    )

    return LaunchDescription([
        use_sim_time_arg,
        LogInfo(msg="=== Multi-Floor Navigation Stack starting ==="),
        map_manager_node,
        elevator_manager_node,
        mission_coordinator_node,
        LogInfo(msg="=== All nodes launched ==="),
    ])
