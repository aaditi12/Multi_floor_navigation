#include "map_manager/map_manager.hpp"

#include <chrono>
#include <functional>

using namespace std::chrono_literals;

namespace map_manager
{

MapManager::MapManager(const rclcpp::NodeOptions & options)
: Node("map_manager_node", options),
  current_floor_(1)
{
  declare_and_load_parameters();
  setup_communication();

  RCLCPP_INFO(get_logger(), "MapManager initialized. Current floor: %d", current_floor_);
}

void MapManager::declare_and_load_parameters()
{
  // Declare parameters with defaults
  declare_parameter<int>("initial_floor", 1);
  declare_parameter<std::string>("floor_1.map_file", "floor_1.yaml");
  declare_parameter<std::string>("floor_1.frame_id", "map_floor_1");
  declare_parameter<std::string>("floor_2.map_file", "floor_2.yaml");
  declare_parameter<std::string>("floor_2.frame_id", "map_floor_2");

  current_floor_ = get_parameter("initial_floor").as_int();

  // Build floor map configuration registry
  FloorMapConfig floor1_cfg;
  floor1_cfg.floor_number = 1;
  floor1_cfg.map_file     = get_parameter("floor_1.map_file").as_string();
  floor1_cfg.frame_id     = get_parameter("floor_1.frame_id").as_string();
  floor_map_configs_[1]   = floor1_cfg;

  FloorMapConfig floor2_cfg;
  floor2_cfg.floor_number = 2;
  floor2_cfg.map_file     = get_parameter("floor_2.map_file").as_string();
  floor2_cfg.frame_id     = get_parameter("floor_2.frame_id").as_string();
  floor_map_configs_[2]   = floor2_cfg;

  RCLCPP_INFO(get_logger(), "Floor 1 map: %s", floor1_cfg.map_file.c_str());
  RCLCPP_INFO(get_logger(), "Floor 2 map: %s", floor2_cfg.map_file.c_str());
}

void MapManager::setup_communication()
{
  floor_info_pub_ = create_publisher<multifloor_interfaces::msg::FloorInfo>(
    "current_floor_info", 10);

  switch_floor_srv_ = create_service<multifloor_interfaces::srv::SwitchFloor>(
    "switch_floor",
    std::bind(&MapManager::handle_switch_floor, this,
      std::placeholders::_1, std::placeholders::_2));

  get_current_floor_srv_ = create_service<multifloor_interfaces::srv::GetCurrentFloor>(
    "get_current_floor",
    std::bind(&MapManager::handle_get_current_floor, this,
      std::placeholders::_1, std::placeholders::_2));

  // Publish floor info at 1 Hz
  publish_timer_ = create_wall_timer(
    1s, std::bind(&MapManager::publish_floor_info, this));
}

void MapManager::publish_floor_info()
{
  auto msg = multifloor_interfaces::msg::FloorInfo{};
  msg.current_floor = current_floor_;
  floor_info_pub_->publish(msg);
}

bool MapManager::load_floor_map(int floor)
{
  auto it = floor_map_configs_.find(floor);
  if (it == floor_map_configs_.end()) {
    RCLCPP_ERROR(get_logger(), "No map config found for floor %d", floor);
    return false;
  }

  const auto & cfg = it->second;
  // In a real system, this would call the map_server lifecycle node or
  // publish a LoadMap action. Here we simulate the map load.
  RCLCPP_INFO(get_logger(),
    "[MapManager] Loading map '%s' with frame '%s' for floor %d",
    cfg.map_file.c_str(), cfg.frame_id.c_str(), floor);
  return true;
}

void MapManager::handle_switch_floor(
  const std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Request> request,
  std::shared_ptr<multifloor_interfaces::srv::SwitchFloor::Response> response)
{
  const int target = request->target_floor;
  RCLCPP_INFO(get_logger(), "SwitchFloor request received: floor %d → floor %d",
    current_floor_, target);

  if (floor_map_configs_.find(target) == floor_map_configs_.end()) {
    response->success = false;
    response->message = "Unknown floor: " + std::to_string(target);
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
    return;
  }

  if (load_floor_map(target)) {
    current_floor_ = target;
    response->success = true;
    response->message = "Switched to floor " + std::to_string(target);
    RCLCPP_INFO(get_logger(), "Successfully switched to floor %d", current_floor_);
  } else {
    response->success = false;
    response->message = "Failed to load map for floor " + std::to_string(target);
    RCLCPP_ERROR(get_logger(), "%s", response->message.c_str());
  }
}

void MapManager::handle_get_current_floor(
  const std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Request> /*request*/,
  std::shared_ptr<multifloor_interfaces::srv::GetCurrentFloor::Response> response)
{
  response->current_floor = current_floor_;
  RCLCPP_DEBUG(get_logger(), "GetCurrentFloor: returning floor %d", current_floor_);
}

}  // namespace map_manager
