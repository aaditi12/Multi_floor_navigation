#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "map_manager/map_manager.hpp"

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<map_manager::MapManager>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
