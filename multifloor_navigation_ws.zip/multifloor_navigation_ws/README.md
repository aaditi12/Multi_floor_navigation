# ROS2 Multi-Floor Navigation — Gazebo + Nav2

A complete ROS2 Humble workspace with **Gazebo Classic simulation**, a
**differential-drive TurtleBot3-style robot**, and a **single Nav2 stack** that
handles navigation on both floors.  Floor switching calls Nav2's real
`map_server/load_map` service; navigation uses the real `NavigateToPose`
action client.

---

## Architecture

```
multifloor_navigation_ws/
└── src/
    ├── multifloor_interfaces/   # Custom msgs & srvs (unchanged)
    ├── multifloor_gazebo/       # ★ NEW — world SDF, robot URDF, PGM maps
    ├── multifloor_nav2/         # ★ NEW — single Nav2 stack params
    ├── map_manager/             # ✎ UPDATED — load_floor_map() calls LoadMap srv
    ├── elevator_manager/        # Elevator FSM (unchanged)
    ├── mission_coordinator/     # ✎ UPDATED — NavigateToPose action client
    └── multifloor_bringup/      # ✎ UPDATED — Gazebo + Nav2 + all nodes
```

### World layout

```
 ┌──────────────┬──────┬──────────────┐
 │  Floor-1     │ Cor- │  Floor-2     │  y = 0..10 m
 │  (0..12 m)   │ridor │ (16..28 m)   │
 │  robot spawn │(12-  │              │
 │  @ (2, 5)    │ 16 m)│ goal e.g.    │
 │              │elev  │ (20, 5)      │
 │    obs       │@13,5 │    obs       │
 └──────────────┴──────┴──────────────┘
```

- Two 12×10 m rooms + a 4 m wide corridor with doorways (y=4..6 m)
- Elevator docking pose: **(13.0, 5.0)** in world/map coordinates
- Each floor has 2 box obstacles for planner testing

### Node graph

```
/mission_goal_floor ──► MissionCoordinator
                           │ NavigateToPose action ──► bt_navigator ──► planner/controller
                           │ /elevator_request      ──► ElevatorManager
                           │ /switch_floor srv      ──► MapManager
                                                            │ map_server/load_map srv ──► map_server (Nav2)
```

### One Nav2 stack — lifecycle nodes managed by lifecycle_manager

```
lifecycle_manager_navigation manages:
  map_server · amcl · controller_server · smoother_server
  planner_server · behavior_server · bt_navigator
  waypoint_follower · velocity_smoother · collision_monitor
```

---

## Prerequisites

| Dependency | Version |
|------------|---------|
| ROS 2 | Humble (Ubuntu 22.04) |
| Gazebo Classic | 11 (ships with `ros-humble-gazebo-ros-pkgs`) |
| Nav2 | `ros-humble-navigation2` |
| TurtleBot3 Gazebo plugins | included via `gazebo_ros` |
| colcon | any recent |

```bash
sudo apt install \
  ros-humble-navigation2 \
  ros-humble-nav2-bringup \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-robot-state-publisher \
  ros-humble-xacro
```

---

## Build

```bash
cd multifloor_navigation_ws
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
```

---

## Run

### Launch everything (Gazebo GUI + Nav2 + all nodes)

```bash
ros2 launch multifloor_bringup bringup.launch.py
```

### Headless (no Gazebo GUI — faster, useful for CI)

```bash
ros2 launch multifloor_bringup bringup.launch.py headless:=true
```

### Send a cross-floor mission (Floor 1 → Floor 2)

```bash
# In a new terminal after sourcing install/setup.bash
ros2 topic pub --once /mission_goal_floor std_msgs/msg/String \
  "data: 'floor:2,x:20.0,y:5.0'"
```

### Send a same-floor mission

```bash
ros2 topic pub --once /mission_goal_floor std_msgs/msg/String \
  "data: 'floor:1,x:8.0,y:7.0'"
```

### Monitor mission progress

```bash
ros2 topic echo /mission_status        # NAVIGATING_TO_ELEVATOR → … → MISSION_COMPLETE
ros2 topic echo /current_floor_info    # floor number
ros2 topic echo /elevator_state        # IDLE → REQUESTED → MOVING → ARRIVED
```

### Set initial AMCL pose (if localisation drifts)

```bash
ros2 topic pub --once /initialpose geometry_msgs/msg/PoseWithCovarianceStamped \
  "{header: {frame_id: map}, pose: {pose: {position: {x: 2.0, y: 5.0}}, \
   covariance: [0.25,0,0,0,0,0, 0,0.25,0,0,0,0, 0,0,0,0,0,0, \
                0,0,0,0,0,0, 0,0,0,0,0,0, 0,0,0,0,0,0.07]}}"
```

---

## Configuration

| Package | File | Key params |
|---------|------|-----------|
| `multifloor_gazebo` | `worlds/multifloor.world` | Wall geometry, obstacles |
| `multifloor_gazebo` | `urdf/robot.urdf.xacro` | Wheel base, lidar range |
| `multifloor_gazebo` | `maps/generate_maps.py` | Map resolution, room dims |
| `multifloor_nav2` | `config/nav2_params.yaml` | DWB speeds, planner tolerance |
| `map_manager` | `config/map_manager_params.yaml` | Floor YAML paths (set by launch) |
| `elevator_manager` | `config/elevator_manager_params.yaml` | `travel_duration_sec` |
| `mission_coordinator` | `config/mission_coordinator_params.yaml` | `elevator_pos_x/y` |

---

## How floor switching works (end-to-end)

1. `MissionCoordinator` calls `/switch_floor` service on `MapManager`.
2. `MapManager.load_floor_map()` calls Nav2's **`map_server/load_map`** service
   with the absolute path to `floor_N.yaml`.
3. `map_server` (lifecycle) reloads the occupancy grid and republishes `/map`.
4. `amcl` receives the new map and re-initialises its particle filter.
5. Global costmap clears and re-inflates from the new static layer.
6. `MissionCoordinator` sends a `NavigateToPose` goal; `bt_navigator` plans
   on the new map.

---

## Regenerating maps

If you change the world geometry, regenerate the PGM files:

```bash
cd src/multifloor_gazebo/maps
python3 generate_maps.py .
```

Then rebuild with `colcon build --symlink-install`.
